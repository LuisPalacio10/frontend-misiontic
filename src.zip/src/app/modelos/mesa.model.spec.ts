import { Mesa } from './mesa.model';

describe('Mesa', () => {
  it('should create an instance', () => {
    expect(new Mesa()).toBeTruthy();
  });
});
