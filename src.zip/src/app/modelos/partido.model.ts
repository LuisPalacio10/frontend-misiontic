export class Partido {
    _id?:string;
    nombre?:string;
    lema?:string;
}
