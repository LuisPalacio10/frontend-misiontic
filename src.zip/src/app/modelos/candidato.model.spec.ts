import { Candidato } from './candidato.model';

describe('Candidato', () => {
  it('should create an instance', () => {
    expect(new Candidato()).toBeTruthy();
  });
});
