export class Mesa {
    _id?:string;
    cantidad_inscritos?:string;
    numero?:string;
}
