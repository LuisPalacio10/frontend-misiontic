export class Resultado {
    _id?:string;
    numero_mesa?:string;
    id_candidato?:string;
    total_votos?:string;
    fecha?:string;
}
