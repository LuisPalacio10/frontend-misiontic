export class Candidato {
    _id?:string;
    cedula?:string;
    nombre?:string;
    apellido?:string;
    numero_resolucion?:string;
    partido?:string;
}
