import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.scss']
})
export class CrearComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
