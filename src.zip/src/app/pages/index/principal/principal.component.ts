import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'ngx-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.scss']
})
export class PrincipalComponent implements OnInit {
  constructor(private router: Router) { }
  ngOnInit(): void {
  }
  goMesas():void{
    console.log("ir a mesas");
    this.router.navigate(["pages/mesas/listar"]);
  }
  goCandidatos():void{
    console.log("ir a mesas");
    this.router.navigate(["pages/candidatos/listar"]);
  }
  goPartidos():void{
    console.log("ir a mesas");
    this.router.navigate(["pages/partidos/listar"]);
  }
  goResultados():void{
    console.log("ir a resultados");
    this.router.navigate(["pages/resultados/listar"]);
  }
  goSalir():void{
    console.log("ir a mesas");
    this.router.navigate(["pages/seguridad/login"]);
  }
}