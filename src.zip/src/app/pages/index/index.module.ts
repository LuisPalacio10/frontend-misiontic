import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IndexRoutingModule } from './index-routing.module';
import { PrincipalComponent } from './principal/principal.component';
import { NbCardModule } from '@nebular/theme';


@NgModule({
  declarations: [
    PrincipalComponent
  ],
  imports: [
    CommonModule,
    IndexRoutingModule,
    NbCardModule
  ]
})
export class IndexModule { }
